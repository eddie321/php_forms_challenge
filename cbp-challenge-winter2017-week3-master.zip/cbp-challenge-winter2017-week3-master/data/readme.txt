Make sure that this folder is writable by php
On Mac OSX try this command (while in this folder in the terminal):
sudo chmod -R a+w .